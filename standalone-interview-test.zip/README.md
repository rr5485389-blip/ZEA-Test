# Interview Test Platform

A single self-contained HTML file (`index.html`) — with instant multi-device & cross-tab synchronization. Can run with the included Express/Vite server, open directly in a browser, or be hosted anywhere that serves static files (e.g. Vercel, Netlify, GitHub Pages).

## Features
- **Real-Time Exam Settings Sync**: When an admin updates test settings (time limit, question count, max tab switches, passing score), changes immediately propagate to the candidate portal across tabs and devices in real-time.
- **Candidate Flow**:
  - Enter name, click "Start test" — name and live progress stay visible on screen throughout.
  - Dynamically receives the questions and countdown timer configured by admin.
  - Switching away from the tab or losing focus is detected and logged with strikes. Configurable max strikes auto-submits and flags the test.
  - Running out of time auto-submits current responses.
- **Admin Portal**:
  - Sign in from landing page ("Admin sign in"). Default password: `admin123` (configurable in Settings).
  - **Knowledge Base**: Add, edit, and delete questions manually, or batch import from a PDF.
  - **Candidates & Scores**: Real-time attempt logs showing candidate name, date, score, percentage, tab switches, and status (passed / failed / flagged / timed-out).
  - **Settings**: Configure time limit (minutes), number of questions per test, allowed tab switches, and passing score percentage.
- **Data Synchronization**:
  - Live Server-Sent Events (SSE) + REST backend (`/api/exam-data`) for multi-device synchronization.
  - `BroadcastChannel` and `storage` events for instant zero-latency sync across same-browser tabs.
  - Cloud JSONBin backup and `localStorage` offline caching.
